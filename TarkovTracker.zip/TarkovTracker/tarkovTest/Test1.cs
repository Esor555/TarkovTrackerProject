﻿using Microsoft.Extensions.Configuration;


namespace tarkovTest
{
    [TestClass]
    public sealed class Test1
    {


       
    
    }
}
