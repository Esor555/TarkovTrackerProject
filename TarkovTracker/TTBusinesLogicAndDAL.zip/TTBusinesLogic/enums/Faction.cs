﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TTBusinesLogic.enums
{
    public enum Faction
    {
        USEC = 1,
        BEAR = 2
    }
}
